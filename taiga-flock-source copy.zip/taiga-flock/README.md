# Taiga Flock — Minecraft Forge 1.20.1

**Target:** Minecraft Java Edition 1.20.1, Forge 47.4.10, Java 17, ForgeGradle 6.x.

Taiga Flock is a vanilla-plus mod prototype focused on blueberry bushes and a more natural chicken life cycle. It is an actively developed source project, not yet a verified release JAR.

## Current implementation in source

### Blueberries
- Sweet-berry-style bush with four vanilla-like growth stages and no prickling damage.
- Mature right-click harvest yields 10 blueberries and resets the bush to an early growth stage.
- Breaking a mature bush can drop 10 blueberries.
- Shovel/hoe loot rules yield 2–4 individual blueberry-leaf items.
- Blueberries restore one hunger point and lure/breed rabbits.
- Blueberry leaves can be eaten to heal 2 health points and are registered as a brewing ingredient for an Awkward Potion to become a Potion of Healing.
- A biome modifier adds blueberry patches to taiga-tagged biomes.

### Heritage chickens
- Custom `Animal` entity rather than `Chicken`, so vanilla chicken egg laying and the vanilla BreedGoal are not inherited.
- A join-level handler replaces vanilla chicken entities with the custom entity; biome modifiers also remove vanilla chicken spawns and add heritage chickens throughout the Overworld.
- Custom cube-built model with sex-specific comb/tail visibility, larger rooster scale, chick scale, walking/wing movement, sitting, and food-carrying in-beak rendering.
- Five plumage colors: white, grey, black, red, buff. Primary appearance and secondary allele are saved separately.
- Red dominance, black/white intermediate expression, grey/buff recessive combinations, freckle modifiers, color mutations, and red-freckle restrictions are implemented in the offspring logic.
- Independent egg-shell color inheritance, including white, brown, blue, light brown, and olive; grey chickens can carry the rare blue-shell trait.
- Adult max health 6, chick max health 3; hunger is 0–5, foraging uses grass blocks/plants and seed items, hunger-zero damage is gradual, and full hunger regenerates health.
- Adult hens and roosters must be opposite sexes and both enter love mode to pair. Hens count down three Minecraft days, gather nest materials by the specified scaled score, and wait for a valid nest location.
- Nest block entity stores the predetermined chick genetics for each egg. A hen must actively sit on the nest for 72,000 ticks (three normal Minecraft days); incubation pauses when she is absent. Eggs render in their inherited colors. Chicks hatch at age zero in the eight-day baby stage and follow their mother closely until day five, then more loosely.
- Roosters can pick up eligible seed/grass/fern item entities, visibly carry an item in the beak, return to their nesting hen, and restore her hunger during incubation.

## Important status and limitations

**This source has not yet completed a successful Forge build or been launched in Minecraft.** The first GitHub Actions compile identified Java API/import mismatches; those reported errors have now been patched in source, but the patched version still needs to pass the next cloud build. No verified release JAR is included yet. Resource checks pass, but those do not prove Java API compatibility or in-game correctness.

This is a substantial first implementation pass, not a claim that every behavior is bug-free. A real Forge build may reveal API or compilation fixes. After compilation, test client/server behavior for entity replacement, spawn rates, rabbit behavior, nest material collection, egg rendering, incubation timing, hatching, and saved-world reloads.

## Get a JAR from GitHub Actions

A workflow is included at `.github/workflows/build.yml`. It sets up Java 17 and Gradle 8.8, validates the resource JSON and texture references, runs `gradle build`, and uploads `build/libs/*.jar` as a workflow artifact. To use it, place this project in a GitHub repository with GitHub Actions enabled and push the source. Open the workflow run and download its **Artifacts** entry. The artifact will exist only if the build succeeds; the workflow does not manufacture a JAR on failure.

## Build on a development machine

1. Install a 64-bit JDK 17.
2. Download the official Forge 1.20.1–47.4.10 MDK from the [Forge downloads page](https://files.minecraftforge.net/net/minecraftforge/forge/index_1.20.1.html).
3. Copy the matching Gradle wrapper files (`gradlew`, `gradlew.bat`, and `gradle/wrapper/`) from that MDK into this project, or install Gradle 8.8.
4. From the project directory, run `./gradlew build` if the wrapper is present, otherwise `gradle --no-daemon build` (Windows: `gradlew.bat build` or `gradle --no-daemon build`).
5. If the build succeeds, the re-obfuscated JAR should be under `build/libs/`.
6. Test it in a separate Forge 1.20.1 instance before using it in a valuable world.

## Offline resource check

Run `python3 scripts/validate_resources.py`. This verifies JSON syntax and referenced mod texture files. It does not compile Java or replace Minecraft tests.

## Useful development commands

- `/summon taigaflock:heritage_chicken` — spawn a heritage chicken.
- `/give @s taigaflock:heritage_chicken_spawn_egg` — obtain its spawn egg.
- `/give @s taigaflock:blueberry_bush` — obtain a blueberry bush block item.
- `/give @s taigaflock:blueberries 16` — obtain blueberries.
- `/give @s taigaflock:blueberry_leaves 16` — obtain medicinal leaves.

## Project layout

- `src/main/java` — mod entry point, registry, blocks, entity, genetics, brewing, and event handlers.
- `src/main/resources/assets/taigaflock` — blockstates, block/item/entity textures, models, and localization.
- `src/main/resources/data/taigaflock` — loot tables and worldgen features.
- `src/main/resources/data/forge/biome_modifier` — spawn and feature biome modifiers.
- `SPECIFICATION.md` — consolidated design rules and implementation notes.
