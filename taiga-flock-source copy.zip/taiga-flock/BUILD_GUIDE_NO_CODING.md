# Build Taiga Flock without installing developer tools

This uses GitHub Actions as a remote build computer. You do not install Java, Gradle, ForgeGradle, or Minecraft build dependencies locally. GitHub downloads those on its hosted runner. A successful build publishes the mod JAR as an artifact.

## Download the correct kit

Download `taiga-flock-cloud-build-kit.zip` and extract it. It contains these visible files:
- `taiga-flock-source.zip` — the complete mod source project.
- `BUILD_WORKFLOW_COPY_ME.yml` — the workflow text you will copy into GitHub.
- `BUILD_GUIDE_NO_CODING.md` — these instructions.

You do **not** need to find a hidden `.github` folder on your Mac. The visible `BUILD_WORKFLOW_COPY_ME.yml` is included specifically so you can open it easily. Do not upload this workflow file at the repository root and expect it to run; GitHub requires the workflow to be saved at `.github/workflows/build.yml` inside your repository.

## Exact steps

1. Go to https://github.com and sign in (or create an account).
2. Click **+** in the upper-right, choose **New repository**, name it `taiga-flock-build`, choose Private if you prefer, and create it with **no README** so the repository starts empty.
3. Upload `taiga-flock-source.zip` from the extracted kit: click **Add file → Upload files**, select the ZIP, then **Commit changes**.
4. Create the workflow file on GitHub. Click **Add file → Create new file**. In the filename box, type exactly `.github/workflows/build.yml` (including the leading dot and both slashes). GitHub should create the folders automatically.
5. On your Mac, open the visible `BUILD_WORKFLOW_COPY_ME.yml` in a plain-text editor (TextEdit works if set to plain text using **Format → Make Plain Text**). Select all and copy the contents. Paste them into GitHub's large editor. Do not include any extra text or Markdown fences.
6. Scroll down, enter a commit message such as `Add automated build workflow`, and click **Commit changes**.
7. Open the repository's **Actions** tab. The workflow should appear as **Build Taiga Flock from source ZIP** and a run should start automatically after the commit. If GitHub asks to enable Actions, enable them.
8. Open the newest workflow run. If it succeeds, scroll to **Artifacts** and download **taiga-flock-jar**. That download is a ZIP; extract it to find the `.jar` inside.
9. Put the `.jar` in your Minecraft instance's `mods` folder and launch **Minecraft Java 1.20.1 with Forge 47.4.10**. Back up your world before testing.

## If the workflow doesn't appear

Confirm that you committed the file at exactly `.github/workflows/build.yml` on the repository's default branch. A file named `build.yml` at the repository root will not run as a GitHub Actions workflow.

## Updating the source after a failed build

If you've already uploaded an older `taiga-flock-source.zip`, you must replace it with the newer one for fixes to be used. In the repository, open the old ZIP file, use the file's **Delete this file** option (often under the `...` menu), and commit that deletion. Then use **Add file → Upload files** to upload the new `taiga-flock-source.zip` and commit. The push should start another workflow run. Leave `.github/workflows/build.yml` in place; you do not need to recreate it.

## If the build fails

Open the failed run, expand the step named **Build and re-obfuscate mod**, and share the first actual error and surrounding log. A failed build does not produce a usable JAR. The first compile errors have been patched in the current source package, but it still needs a successful cloud build and in-game testing.

## Downloads and size

You do not download a JDK, Gradle, Forge MDK, or Minecraft/Forge dependency libraries to your computer. GitHub downloads those on its own runner. Your local downloads are only the small source/build kit and, after a successful build, the JAR artifact ZIP.
