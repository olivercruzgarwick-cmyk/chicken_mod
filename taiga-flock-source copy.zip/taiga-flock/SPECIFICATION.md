# Taiga Flock — consolidated design specification

## Target
- Minecraft Java 1.20.1
- Forge 47.4.10
- Java 17 / ForgeGradle 6.x
- Vanilla-plus scope: blueberries plus a more complex chicken ecosystem

## Blueberry plant
- Appears in all taiga biomes through the taiga biome tag.
- Four growth stages, visually inspired by the vanilla sweet berry bush.
- Never hurts or slows entities.
- A mature bush gives 10 blueberries on harvest; breaking a mature bush can also yield 10.
- Blueberries restore 1 hunger point and can lure/breed rabbits.
- Breaking the bush with a shovel or hoe yields 2–4 blueberry leaves as individual items.
- Leaves are edible and heal 2 health points; brewing leaves with an Awkward Potion yields a Potion of Healing.

## Chicken entity and appearance
- Custom entity replaces vanilla chicken entities and vanilla chicken world spawns.
- Separate sex value: HEN or ROOSTER. Only opposite-sex adults pair.
- Roosters are slightly larger, with a more pronounced comb and fuller tail. Hens do not display the rooster comb/tail.
- Custom cube-built model with walking/wing movement, sitting, chick scaling, and beak-carried item rendering. Animation scope stays intentionally modest.
- Five primary plumage colors: WHITE, GREY, BLACK, RED, BUFF.
- Chick texture is yellow for white/buff/red primary plumage, grey for grey/black primary plumage.

## Plumage genetics
- Every chicken stores its primary appearance and a secondary allele independently.
- Dominance hierarchy: RED > BLACK/WHITE > GREY/BUFF.
- BLACK and WHITE are intermediate: one generally expresses as primary, with a modifier-driven chance of freckles in the other color.
- GREY + BUFF heterozygotes always express grey or buff with freckles in the other color.
- Freckles and freckle color are separate saved traits.
- Breeding has an independent 1-in-14 plumage mutation and 1-in-14 freckle mutation.
- Mutation map:
  - Grey → Black or White
  - White → Grey or Buff
  - Black → Grey or Red
  - Red → Black or Buff
  - Buff → White or Red
- Red freckles are only allowed on white or buff primary plumage; invalid combinations are converted to grey freckles.

## Egg-shell genetics
- Natural base egg color: buff/black/red → brown; white → white; grey → white unless it carries the blue-shell trait.
- The blue-shell trait is a rare mutation originating in grey birds; it can be inherited by offspring of other colors as a hidden trait.
- Stored egg colors: WHITE, BROWN, BLUE, LIGHT_BROWN, OLIVE.
- Inheritance:
  - Same visible colors normally breed true.
  - White + brown → light brown.
  - Brown + blue → olive.
  - Blue + white → white.
  - Olive + olive has a 30% blue outcome; olive + blue has a 65% blue outcome.
  - Other combinations use a documented probabilistic fallback in `EggGenetics`.
- Each egg's chick genetics and egg-shell color are determined when the clutch is laid, then saved in the nest block entity.

## Pairing, laying, and nests
- Breeding begins when an adult hen and rooster are both in love mode and within 6 blocks.
- Hens count down 3 full normal Minecraft days (72,000 ticks) before laying.
- During this period, the hen searches nearby areas for nest materials and attempts to build a nest once the score reaches 5.
- Scaled internal score uses half-points to preserve fractional values:
  - Short grass: 0.5 (1 scaled point)
  - Tall grass/fern/large fern: 1 (2 scaled points)
  - Feather item: 3 (6 scaled points)
  - Stick item: 1.5 (3 scaled points)
  - Cobweb block: 3 (6 scaled points)
- Nests can be placed only above dirt, grass block, gravel, or sand.
- A nest cannot be within 5 blocks of water or 3 blocks of farmland.
- If no valid nest/materials are available, the hen waits rather than laying on the ground.
- Clutch distribution: 1 egg 10%, 2 eggs 20%, 3 eggs 40%, 4 eggs 20%, 5 eggs 10%.
- The hen must actively sit on the nest for three full days. If she leaves or dies, incubation pauses; elapsed incubation is preserved.
- Nests persist after hatching and can be reused as blocks, and empty nests can be reused by later clutches.
- Roosters pick up seed/grass/fern item entities, carry them in the beak, return to the incubating hen, and restore her hunger. They stop tending once the clutch hatches.

## Hunger, health, and growth
- Hunger range 0–5; chicks hatch at 5/5.
- Grass block eaten while standing on it → dirt, +3 hunger.
- Short grass, tall grass, or fern growing on a grass block → remove plant, +2 hunger.
- Seed items or player-fed seeds → +3 hunger.
- Hunger decreases slowly over time; at zero, health damage begins at a slow interval.
- Full hunger regenerates 1 health point gradually.
- Adult max health: 6 (3 hearts). Chick max health: 3 (1.5 hearts).
- Chick stage lasts 8 full Minecraft days.
- Chicks follow their mother closely for days 0–5, then follow more loosely for days 5–8.

## Implementation/testing notes
- The project source includes the systems above as an initial integrated implementation pass.
- A real Forge build and in-game validation are still required. The authoring environment lacks Gradle, JDK 17, and network access to Forge Maven, so no compiled JAR is claimed.
- Known testing priorities: build/API compatibility, entity replacement, dedicated-server startup, biome modifier decoding, rabbit temptation duplication across reloads, nest placement and material gathering, carried item rendering, egg persistence/rendering, incubation pause/resume, and offspring save/load.


## Build status note (2026-10-20)

The first GitHub Actions compile surfaced Java API naming/import issues in the custom chicken renderer/model, grass item/block names, blueberry-leaf food properties, and nest block shape. These have been patched in the latest source archive. The patch has passed the JSON/model/texture resource checker; the next Forge build is still required to confirm compilation.
