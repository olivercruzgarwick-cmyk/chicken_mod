package com.gungle.taigaflock.entity;

import net.minecraft.util.RandomSource;

/** Probability-based inheritance for the egg-shell trait, kept separate from plumage genetics. */
public final class EggGenetics {
    public enum Color { WHITE, BROWN, BLUE, LIGHT_BROWN, OLIVE }

    private EggGenetics() {}

    public static Color inherit(Color first, Color second, RandomSource random) {
        if (first == second) {
            // Olive is an exception to simple true-breeding: its mixed ancestry can reveal blue.
            if (first == Color.OLIVE && random.nextFloat() < 0.30F) return Color.BLUE;
            return first;
        }
        if (isPair(first, second, Color.WHITE, Color.BROWN)) return Color.LIGHT_BROWN;
        if (isPair(first, second, Color.BROWN, Color.BLUE)) return Color.OLIVE;
        if (isPair(first, second, Color.BLUE, Color.WHITE)) return Color.WHITE;
        if (isPair(first, second, Color.OLIVE, Color.BLUE)) return random.nextFloat() < 0.65F ? Color.BLUE : Color.OLIVE;
        if (isPair(first, second, Color.OLIVE, Color.LIGHT_BROWN)) return random.nextFloat() < 0.45F ? Color.OLIVE : Color.LIGHT_BROWN;
        if (isPair(first, second, Color.BLUE, Color.LIGHT_BROWN)) return random.nextFloat() < 0.35F ? Color.OLIVE : Color.LIGHT_BROWN;
        // Unspecified mixed combinations inherit one parent's visible shell color.
        return random.nextBoolean() ? first : second;
    }

    public static Color shellColor(HeritageChicken.Plumage primary, boolean blueEggGene) {
        if (primary == HeritageChicken.Plumage.GREY && blueEggGene) return Color.BLUE;
        return switch (primary) {
            case WHITE -> Color.WHITE;
            case GREY -> Color.WHITE;
            case BLACK, RED, BUFF -> Color.BROWN;
        };
    }

    private static boolean isPair(Color a, Color b, Color x, Color y) {
        return (a == x && b == y) || (a == y && b == x);
    }
}
