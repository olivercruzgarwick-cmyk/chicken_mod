package com.gungle.taigaflock.brewing;

import com.gungle.taigaflock.registry.ModContent;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.alchemy.PotionUtils;
import net.minecraft.world.item.alchemy.Potions;
import net.minecraftforge.common.brewing.IBrewingRecipe;

/** Blueberry leaves convert an Awkward Potion into a standard Potion of Healing. */
public final class BlueberryHealingBrewingRecipe implements IBrewingRecipe {
    @Override
    public boolean isInput(ItemStack input) {
        return input.is(Items.POTION) && PotionUtils.getPotion(input) == Potions.AWKWARD;
    }

    @Override
    public boolean isIngredient(ItemStack ingredient) {
        return ingredient.is(ModContent.BLUEBERRY_LEAVES.get());
    }

    @Override
    public ItemStack getOutput(ItemStack input, ItemStack ingredient) {
        if (!isInput(input) || !isIngredient(ingredient)) return ItemStack.EMPTY;
        return PotionUtils.setPotion(new ItemStack(Items.POTION), Potions.HEALING);
    }
}
