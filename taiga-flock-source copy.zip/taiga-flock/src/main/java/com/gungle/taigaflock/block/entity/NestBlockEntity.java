package com.gungle.taigaflock.block.entity;

import com.gungle.taigaflock.entity.HeritageChicken;
import com.gungle.taigaflock.registry.ModContent;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

/** Stores each chick's already-determined genetics in the egg and tracks active incubation. */
public class NestBlockEntity extends BlockEntity {
    private final ListTag eggData = new ListTag();
    private int incubationTicks;
    private long lastHenPresence = Long.MIN_VALUE / 2;

    public NestBlockEntity(BlockPos pos, BlockState state) {
        super(ModContent.NEST_BLOCK_ENTITY.get(), pos, state);
    }

    public int getEggCount() { return eggData.size(); }
    public com.gungle.taigaflock.entity.EggGenetics.Color getEggColorAt(int index) {
        if (index < 0 || index >= eggData.size()) return com.gungle.taigaflock.entity.EggGenetics.Color.WHITE;
        CompoundTag chick = eggData.getCompound(index);
        int value = chick.getByte("TfEggColor");
        return com.gungle.taigaflock.entity.EggGenetics.Color.values()[Math.floorMod(value, com.gungle.taigaflock.entity.EggGenetics.Color.values().length)];
    }
    public int getIncubationTicks() { return incubationTicks; }

    public void recordHenPresence() {
        if (level != null && !level.isClientSide) {
            lastHenPresence = level.getGameTime();
            setChanged();
        }
    }

    /** Saves pre-generated chicks, so color mutations are decided when the clutch is laid. */
    public void setClutch(java.util.List<HeritageChicken> chicks) {
        eggData.clear();
        if (level instanceof ServerLevel serverLevel) {
            for (HeritageChicken chick : chicks) {
                chick.setPos(worldPosition.getX() + 0.5, worldPosition.getY() + 0.35, worldPosition.getZ() + 0.5);
                eggData.add(chick.saveWithoutId(new CompoundTag()));
                chick.discard();
            }
            incubationTicks = 0;
            lastHenPresence = Long.MIN_VALUE / 2;
            setChanged();
            serverLevel.sendBlockUpdated(worldPosition, getBlockState(), getBlockState(), 3);
        }
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, NestBlockEntity nest) {
        if (!(level instanceof ServerLevel serverLevel) || nest.eggData.isEmpty()) return;
        long now = level.getGameTime();
        // A hen must actively tend the nest. Missing her pauses, rather than resets, the timer.
        if (now - nest.lastHenPresence <= 1L) {
            nest.incubationTicks++;
            nest.setChanged();
        }
        if (nest.incubationTicks < 3 * 24000) return;

        for (int i = 0; i < nest.eggData.size(); i++) {
            CompoundTag chickTag = nest.eggData.getCompound(i);
            HeritageChicken chick = ModContent.HERITAGE_CHICKEN.get().create(serverLevel);
            if (chick == null) continue;
            chick.load(chickTag.copy());
            chick.setPos(pos.getX() + 0.5 + (serverLevel.random.nextDouble() - 0.5) * 0.5,
                    pos.getY() + 0.25, pos.getZ() + 0.5 + (serverLevel.random.nextDouble() - 0.5) * 0.5);
            chick.setAge(-8 * 24000);
            chick.setHunger(5);
            serverLevel.addFreshEntity(chick);
        }
        nest.eggData.clear();
        nest.incubationTicks = 0;
        nest.setChanged();
        serverLevel.sendBlockUpdated(pos, state, state, 3);
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.put("EggData", eggData.copy());
        tag.putInt("IncubationTicks", incubationTicks);
        tag.putLong("LastHenPresence", lastHenPresence);
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        eggData.clear();
        if (tag.contains("EggData", Tag.TAG_LIST)) eggData.addAll(tag.getList("EggData", Tag.TAG_COMPOUND));
        incubationTicks = Math.max(0, tag.getInt("IncubationTicks"));
        lastHenPresence = tag.getLong("LastHenPresence");
    }
}
