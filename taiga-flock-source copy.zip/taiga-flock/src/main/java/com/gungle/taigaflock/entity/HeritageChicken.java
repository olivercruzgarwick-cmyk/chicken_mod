package com.gungle.taigaflock.entity;

import com.gungle.taigaflock.registry.ModContent;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.PanicGoal;
import net.minecraft.world.entity.ai.goal.TemptGoal;
import net.minecraft.world.entity.ai.goal.FollowParentGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.item.ItemEntity;
import com.gungle.taigaflock.block.entity.NestBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.SpawnGroupData;
import javax.annotation.Nullable;
import net.minecraft.util.RandomSource;

/**
 * First-pass custom chicken entity. This establishes persistent genetic/sex/hunger data.
 * Nesting, incubation, item carrying, custom rendering, and full inheritance are staged separately.
 */
public class HeritageChicken extends Animal {
    public enum Plumage { WHITE, GREY, BLACK, RED, BUFF }
    public enum Sex { HEN, ROOSTER }

    private static final EntityDataAccessor<Byte> SEX = SynchedEntityData.defineId(HeritageChicken.class, EntityDataSerializers.BYTE);
    private static final EntityDataAccessor<Byte> PRIMARY = SynchedEntityData.defineId(HeritageChicken.class, EntityDataSerializers.BYTE);
    private static final EntityDataAccessor<Byte> SECONDARY = SynchedEntityData.defineId(HeritageChicken.class, EntityDataSerializers.BYTE);
    private static final EntityDataAccessor<Boolean> FRECKLED = SynchedEntityData.defineId(HeritageChicken.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Byte> FRECKLE_COLOR = SynchedEntityData.defineId(HeritageChicken.class, EntityDataSerializers.BYTE);
    private static final EntityDataAccessor<Byte> HUNGER = SynchedEntityData.defineId(HeritageChicken.class, EntityDataSerializers.BYTE);
    private static final EntityDataAccessor<Boolean> BLUE_EGG_GENE = SynchedEntityData.defineId(HeritageChicken.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> SITTING_FOR_NEST = SynchedEntityData.defineId(HeritageChicken.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Byte> EGG_COLOR = SynchedEntityData.defineId(HeritageChicken.class, EntityDataSerializers.BYTE);
    private static final EntityDataAccessor<ItemStack> CARRIED_ITEM = SynchedEntityData.defineId(HeritageChicken.class, EntityDataSerializers.ITEM_STACK);
    private static final EntityDataAccessor<Boolean> FEEDING = SynchedEntityData.defineId(HeritageChicken.class, EntityDataSerializers.BOOLEAN);

    private int hungerTick;
    private int regenTick;
    private int starvationTick;
    private int forageCooldown;
    private int prelayTicks = -1;
    private int nestMaterialScore;
    private int nestRetryTicks;
    private java.util.UUID partnerUuid;
    private java.util.UUID motherUuid;
    private BlockPos nestPos;
    private boolean nestStarted;

    public HeritageChicken(EntityType<? extends Animal> type, Level level) {
        super(type, level);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new PanicGoal(this, 1.4D));
        this.goalSelector.addGoal(2, new TemptGoal(this, 1.0D, Ingredient.of(Items.WHEAT_SEEDS, Items.BEETROOT_SEEDS, Items.MELON_SEEDS, Items.PUMPKIN_SEEDS), false));
        this.goalSelector.addGoal(3, new FollowParentGoal(this, 1.1D));
        this.goalSelector.addGoal(4, new WaterAvoidingRandomStrollGoal(this, 1.0D));
        this.goalSelector.addGoal(5, new LookAtPlayerGoal(this, Player.class, 6.0F));
        this.goalSelector.addGoal(6, new RandomLookAroundGoal(this));
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(SEX, (byte) (this.random.nextBoolean() ? Sex.HEN.ordinal() : Sex.ROOSTER.ordinal()));
        this.entityData.define(PRIMARY, (byte) Plumage.WHITE.ordinal());
        this.entityData.define(SECONDARY, (byte) Plumage.WHITE.ordinal());
        this.entityData.define(FRECKLED, false);
        this.entityData.define(FRECKLE_COLOR, (byte) Plumage.GREY.ordinal());
        this.entityData.define(HUNGER, (byte) 5);
        this.entityData.define(BLUE_EGG_GENE, false);
        this.entityData.define(SITTING_FOR_NEST, false);
        this.entityData.define(EGG_COLOR, (byte) EggGenetics.Color.WHITE.ordinal());
        this.entityData.define(CARRIED_ITEM, ItemStack.EMPTY);
        this.entityData.define(FEEDING, false);
    }

    public Sex getSex() { return Sex.values()[Math.floorMod(this.entityData.get(SEX), Sex.values().length)]; }
    public Plumage getPrimaryColor() { return Plumage.values()[Math.floorMod(this.entityData.get(PRIMARY), Plumage.values().length)]; }
    public Plumage getSecondaryAllele() { return Plumage.values()[Math.floorMod(this.entityData.get(SECONDARY), Plumage.values().length)]; }
    public boolean hasFreckles() { return this.entityData.get(FRECKLED); }
    public Plumage getFreckleColor() { return Plumage.values()[Math.floorMod(this.entityData.get(FRECKLE_COLOR), Plumage.values().length)]; }
    public int getHunger() { return this.entityData.get(HUNGER); }
    public boolean hasBlueEggGene() { return this.entityData.get(BLUE_EGG_GENE); }
    public boolean isSittingForNest() { return this.entityData.get(SITTING_FOR_NEST); }
    public void setSittingForNest(boolean sitting) { this.entityData.set(SITTING_FOR_NEST, sitting); }
    public EggGenetics.Color getEggColor() { return EggGenetics.Color.values()[Math.floorMod(this.entityData.get(EGG_COLOR), EggGenetics.Color.values().length)]; }
    public BlockPos getNestPos() { return nestPos; }
    public boolean hasActiveNest() { return nestPos != null; }
    public ItemStack getCarriedItem() { return this.entityData.get(CARRIED_ITEM); }
    public void setCarriedItem(ItemStack stack) { this.entityData.set(CARRIED_ITEM, stack.isEmpty() ? ItemStack.EMPTY : stack.copyWithCount(1)); }
    public boolean isFeedingPartner() { return this.entityData.get(FEEDING); }

    public void setGenetics(Plumage primary, Plumage secondary, boolean freckles, Plumage freckleColor, boolean blueEggGene) {
        this.entityData.set(PRIMARY, (byte) primary.ordinal());
        this.entityData.set(SECONDARY, (byte) secondary.ordinal());
        this.entityData.set(FRECKLED, freckles);
        this.entityData.set(FRECKLE_COLOR, (byte) freckleColor.ordinal());
        this.entityData.set(BLUE_EGG_GENE, blueEggGene);
    }

    public void setHunger(int value) { this.entityData.set(HUNGER, (byte) Math.max(0, Math.min(5, value))); }

    @Override
    public boolean isFood(ItemStack stack) {
        return stack.is(Items.WHEAT_SEEDS) || stack.is(Items.BEETROOT_SEEDS)
                || stack.is(Items.MELON_SEEDS) || stack.is(Items.PUMPKIN_SEEDS);
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack held = player.getItemInHand(hand);
        if (isFood(held) && getHunger() < 5) {
            if (!this.level().isClientSide) {
                feedFor(3);
                if (!player.getAbilities().instabuild) held.shrink(1);
            }
            return InteractionResult.sidedSuccess(this.level().isClientSide);
        }
        return super.mobInteract(player, hand);
    }

    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty, MobSpawnType reason, @Nullable SpawnGroupData spawnData, @Nullable CompoundTag dataTag) {
        SpawnGroupData result = super.finalizeSpawn(level, difficulty, reason, spawnData, dataTag);
        if (reason != MobSpawnType.BREEDING) {
            Plumage first = Plumage.values()[this.random.nextInt(Plumage.values().length)];
            Plumage second = Plumage.values()[this.random.nextInt(Plumage.values().length)];
            // Red has the highest expression chance; black and white are intermediate, grey and buff recessive.
            if (this.random.nextFloat() < 0.28F) first = Plumage.RED;
            else if (this.random.nextFloat() < 0.5F) first = this.random.nextBoolean() ? Plumage.BLACK : Plumage.WHITE;
            else if (this.random.nextFloat() < 0.6F) first = this.random.nextBoolean() ? Plumage.GREY : Plumage.BUFF;
            boolean freckles = this.random.nextFloat() < 0.22F;
            Plumage spot = Plumage.values()[this.random.nextInt(Plumage.values().length)];
            if (spot == Plumage.RED && first != Plumage.WHITE && first != Plumage.BUFF) spot = Plumage.GREY;
            boolean blueGene = first == Plumage.GREY && this.random.nextInt(128) == 0;
            setGenetics(first, second, freckles, spot, blueGene);
        }
        this.entityData.set(EGG_COLOR, (byte) EggGenetics.shellColor(getPrimaryColor(), hasBlueEggGene()).ordinal());
        return result;
    }
    public void feedFor(int points) { setHunger(getHunger() + points); }

    @Override public boolean canMate(Animal other) {
        return other instanceof HeritageChicken chicken && chicken != this
                && chicken.getSex() != this.getSex() && super.canMate(other);
    }

    @Override public AgeableMob getBreedOffspring(ServerLevel level, AgeableMob partner) {
        HeritageChicken child = ModContent.HERITAGE_CHICKEN.get().create(level);
        if (child == null || !(partner instanceof HeritageChicken other)) return child;
        RandomSource random = this.random;
        Plumage alleleA = random.nextBoolean() ? this.getPrimaryColor() : this.getSecondaryAllele();
        Plumage alleleB = random.nextBoolean() ? other.getPrimaryColor() : other.getSecondaryAllele();
        Plumage inheritedPrimary = expressAlleles(alleleA, alleleB, random);
        Plumage inheritedSecondary = alleleA == inheritedPrimary ? alleleB : alleleA;
        boolean freckles = random.nextBoolean() ? this.hasFreckles() : other.hasFreckles();
        Plumage freckleColor = random.nextBoolean() ? this.getFreckleColor() : other.getFreckleColor();

        // Two different recessive alleles always express the distinctive grey/buff freckle pattern.
        if (isOppositePair(alleleA, alleleB, Plumage.GREY, Plumage.BUFF)) {
            inheritedPrimary = random.nextBoolean() ? Plumage.GREY : Plumage.BUFF;
            inheritedSecondary = inheritedPrimary == Plumage.GREY ? Plumage.BUFF : Plumage.GREY;
            freckles = true;
            freckleColor = inheritedSecondary;
        } else if (isOppositePair(alleleA, alleleB, Plumage.BLACK, Plumage.WHITE)) {
            // Black and white are incompletely dominant: one is primary, with a modifier-driven chance of spots.
            inheritedPrimary = random.nextFloat() < 0.55F ? Plumage.BLACK : Plumage.WHITE;
            inheritedSecondary = inheritedPrimary == Plumage.BLACK ? Plumage.WHITE : Plumage.BLACK;
            if (random.nextFloat() < 0.35F) {
                freckles = true;
                freckleColor = inheritedSecondary;
            }
        }

        // Independent 1-in-14 color mutations: one for plumage and one for the freckle trait.
        if (random.nextInt(14) == 0) inheritedPrimary = mutate(inheritedPrimary, random);
        if (random.nextInt(14) == 0) {
            if (!freckles) {
                freckles = true;
                freckleColor = mutate(inheritedPrimary, random);
            } else {
                freckleColor = mutate(freckleColor, random);
            }
        }
        boolean blueGene = (this.hasBlueEggGene() || other.hasBlueEggGene()) && random.nextFloat() < 0.65F;
        // The blue-shell trait originates as a rare mutation in grey birds, but can be carried by other colors.
        if (!blueGene && inheritedPrimary == Plumage.GREY && random.nextInt(128) == 0) blueGene = true;
        if (freckleColor == Plumage.RED && inheritedPrimary != Plumage.WHITE && inheritedPrimary != Plumage.BUFF)
            freckleColor = Plumage.GREY;
        child.setGenetics(inheritedPrimary, inheritedSecondary, freckles, freckleColor, blueGene);
        EggGenetics.Color eggColor = EggGenetics.inherit(this.getEggColor(), other.getEggColor(), random);
        child.entityData.set(EGG_COLOR, (byte) eggColor.ordinal());
        child.setHunger(5);
        child.setAge(-8 * 24000);
        return child;
    }

    private static Plumage expressAlleles(Plumage a, Plumage b, RandomSource random) {
        if (a == b) return a;
        if (a == Plumage.RED || b == Plumage.RED) return Plumage.RED;
        if (a == Plumage.BLACK && b == Plumage.WHITE || a == Plumage.WHITE && b == Plumage.BLACK)
            return random.nextFloat() < 0.55F ? Plumage.BLACK : Plumage.WHITE;
        int da = dominance(a), db = dominance(b);
        return da >= db ? a : b;
    }

    private static boolean isOppositePair(Plumage a, Plumage b, Plumage x, Plumage y) {
        return (a == x && b == y) || (a == y && b == x);
    }

    private static int dominance(Plumage c) { return switch (c) { case RED -> 3; case BLACK, WHITE -> 2; case GREY, BUFF -> 1; }; }

    private static Plumage mutate(Plumage c, RandomSource r) {
        return switch (c) {
            case GREY -> r.nextBoolean() ? Plumage.BLACK : Plumage.WHITE;
            case WHITE -> r.nextBoolean() ? Plumage.GREY : Plumage.BUFF;
            case BLACK -> r.nextBoolean() ? Plumage.GREY : Plumage.RED;
            case RED -> r.nextBoolean() ? Plumage.BLACK : Plumage.BUFF;
            case BUFF -> r.nextBoolean() ? Plumage.WHITE : Plumage.RED;
        };
    }

    @Override public void tick() {
        boolean wasBaby = this.isBaby();
        super.tick();
        if (this.level().isClientSide) return;

        AttributeInstance maxHealth = this.getAttribute(Attributes.MAX_HEALTH);
        if (maxHealth != null) {
            maxHealth.setBaseValue(this.isBaby() ? 3.0D : 6.0D);
            if (this.getHealth() > maxHealth.getValue()) this.setHealth((float) maxHealth.getValue());
        }
        if (wasBaby && !this.isBaby()) this.setHealth(6.0F);

        // All ages forage. A full hunger bar slowly regenerates health; starvation is deliberately gradual.
        if (++hungerTick >= 24000) {
            hungerTick = 0;
            if (getHunger() > 0) setHunger(getHunger() - 1);
        }
        if (getHunger() == 0) {
            if (++starvationTick >= 1200) {
                starvationTick = 0;
                hurt(this.damageSources().starve(), 1.0F);
            }
        } else starvationTick = 0;
        if (getHunger() == 5 && this.getHealth() < this.getMaxHealth() && ++regenTick >= 1200) {
            regenTick = 0;
            this.heal(1.0F);
        } else if (getHunger() < 5) regenTick = 0;

        if (forageCooldown > 0) forageCooldown--;
        if (getHunger() <= 3 && forageCooldown == 0) forage();
        if (this.isBaby() && motherUuid != null) followMother();
        updatePairingAndNesting();
        updateRoosterFeeding();
    }

    private int feedingAnimationTicks;

    private void updateRoosterFeeding() {
        if (feedingAnimationTicks > 0) feedingAnimationTicks--;
        this.entityData.set(FEEDING, feedingAnimationTicks > 0);
        if (getSex() != Sex.ROOSTER || partnerUuid == null || !(this.level() instanceof ServerLevel)) return;
        net.minecraft.world.entity.Entity entity = ((ServerLevel) this.level()).getEntity(partnerUuid);
        if (!(entity instanceof HeritageChicken hen) || hen.getSex() != Sex.HEN || !hen.hasActiveNest()) {
            setCarriedItem(ItemStack.EMPTY);
            return;
        }
        BlockEntity be = this.level().getBlockEntity(hen.getNestPos());
        if (!(be instanceof NestBlockEntity nest) || nest.getEggCount() <= 0 || hen.getHunger() >= 5) {
            return;
        }
        if (getCarriedItem().isEmpty()) {
            ItemEntity nearest = null;
            double nearestDistance = Double.MAX_VALUE;
            for (ItemEntity item : this.level().getEntitiesOfClass(ItemEntity.class, this.getBoundingBox().inflate(8.0D))) {
                if (!isNestFood(item.getItem())) continue;
                double distance = this.distanceToSqr(item);
                if (distance < nearestDistance) { nearest = item; nearestDistance = distance; }
            }
            if (nearest == null) return;
            if (nearestDistance > 2.25D) {
                this.getNavigation().moveTo(nearest, 1.1D);
                return;
            }
            ItemStack stack = nearest.getItem();
            ItemStack carried = stack.copyWithCount(1);
            stack.shrink(1);
            if (stack.isEmpty()) nearest.discard(); else nearest.setItem(stack);
            setCarriedItem(carried);
        }
        if (getCarriedItem().isEmpty()) return;
        if (this.distanceToSqr(hen) > 3.0D) {
            this.getNavigation().moveTo(hen, 1.15D);
        } else {
            this.getNavigation().stop();
            feedingAnimationTicks = 12;
            this.entityData.set(FEEDING, true);
            hen.feedFor(getCarriedItem().is(Items.WHEAT_SEEDS) || getCarriedItem().is(Items.BEETROOT_SEEDS)
                    || getCarriedItem().is(Items.MELON_SEEDS) || getCarriedItem().is(Items.PUMPKIN_SEEDS) ? 3 : 2);
            setCarriedItem(ItemStack.EMPTY);
        }
    }

    private static boolean isNestFood(ItemStack stack) {
        return stack.is(Items.WHEAT_SEEDS) || stack.is(Items.BEETROOT_SEEDS) || stack.is(Items.MELON_SEEDS)
                || stack.is(Items.PUMPKIN_SEEDS) || stack.is(Items.GRASS) || stack.is(Items.TALL_GRASS)
                || stack.is(Items.FERN) || stack.is(Items.LARGE_FERN);
    }

    private void forage() {
        forageCooldown = 100;
        BlockPos below = this.blockPosition().below();
        if (this.level().getBlockState(below).is(Blocks.GRASS_BLOCK)) {
            this.level().setBlock(below, Blocks.DIRT.defaultBlockState(), 3);
            feedFor(3);
            return;
        }
        BlockPos origin = this.blockPosition();
        for (BlockPos pos : BlockPos.betweenClosed(origin.offset(-1, -1, -1), origin.offset(1, 1, 1))) {
            BlockState state = this.level().getBlockState(pos);
            if ((state.is(Blocks.GRASS) || state.is(Blocks.TALL_GRASS) || state.is(Blocks.FERN) || state.is(Blocks.LARGE_FERN))
                    && this.level().getBlockState(pos.below()).is(Blocks.GRASS_BLOCK)) {
                this.level().destroyBlock(pos, false);
                feedFor(2);
                return;
            }
        }
        for (ItemEntity item : this.level().getEntitiesOfClass(ItemEntity.class, this.getBoundingBox().inflate(2.0D))) {
            ItemStack stack = item.getItem();
            if (isFood(stack)) {
                stack.shrink(1);
                if (stack.isEmpty()) item.discard(); else item.setItem(stack);
                feedFor(3);
                return;
            }
        }
    }

    private void followMother() {
        if (motherUuid == null || this.isBaby() == false) return;
        net.minecraft.world.entity.Entity mother = this.level() instanceof ServerLevel serverLevel ? serverLevel.getEntity(motherUuid) : null;
        if (!(mother instanceof HeritageChicken hen) || hen.isRemoved()) return;
        double distance = this.distanceToSqr(hen);
        double maxDistance = this.getAge() < -3 * 24000 ? 2.5D : 7.0D;
        if (distance > maxDistance * maxDistance) {
            this.getNavigation().moveTo(hen, this.getAge() < -3 * 24000 ? 1.25D : 0.95D);
        }
    }

    private void updatePairingAndNesting() {
        if (!(this.level() instanceof ServerLevel serverLevel) || this.isBaby()) return;
        if (this.isInLove() && partnerUuid == null) {
            for (HeritageChicken other : this.level().getEntitiesOfClass(HeritageChicken.class, this.getBoundingBox().inflate(6.0D))) {
                if (other == this || other.getSex() == this.getSex() || !other.isInLove() || other.partnerUuid != null) continue;
                this.partnerUuid = other.getUUID();
                other.partnerUuid = this.getUUID();
                this.setInLoveTime(0);
                other.setInLoveTime(0);
                if (this.getSex() == Sex.HEN) this.prelayTicks = 3 * 24000;
                else other.prelayTicks = 3 * 24000;
                break;
            }
        }

        if (getSex() == Sex.HEN && partnerUuid != null && prelayTicks >= 0) {
            if (prelayTicks > 0) prelayTicks--;
            if (nestPos == null && --nestRetryTicks <= 0) {
                nestRetryTicks = 200;
                tryBuildNest(serverLevel);
            }
            if (prelayTicks == 0 && nestPos != null) {
                BlockEntity waiting = this.level().getBlockEntity(nestPos);
                if (waiting instanceof NestBlockEntity nest && nest.getEggCount() == 0) layClutch(serverLevel, nest);
            }
        }

        if (getSex() == Sex.HEN && nestPos != null) {
            BlockEntity be = this.level().getBlockEntity(nestPos);
            if (!(be instanceof NestBlockEntity nest)) {
                setSittingForNest(false);
                nestPos = null;
                return;
            }
            // The nest can be built during the three-day pre-laying period, but incubation starts only once eggs are laid.
            if (nest.getEggCount() == 0 && prelayTicks >= 0) {
                setSittingForNest(false);
                return;
            }
            if (nest.getEggCount() == 0) {
                setSittingForNest(false);
                nestPos = null;
                if (partnerUuid != null && serverLevel.getEntity(partnerUuid) instanceof HeritageChicken rooster) {
                    rooster.partnerUuid = null;
                    rooster.setCarriedItem(ItemStack.EMPTY);
                }
                partnerUuid = null;
                prelayTicks = -1;
                return;
            }
            if (this.blockPosition().distSqr(nestPos) > 2.25D) {
                setSittingForNest(false);
                this.getNavigation().moveTo(nestPos.getX() + 0.5, nestPos.getY() + 0.3, nestPos.getZ() + 0.5, 1.0D);
            } else {
                this.getNavigation().stop();
                setSittingForNest(true);
                nest.recordHenPresence();
            }
        }
    }

    private void tryBuildNest(ServerLevel serverLevel) {
        BlockPos center = this.blockPosition();
        // Empty nests persist and can be reused by later clutches.
        for (BlockPos pos : BlockPos.betweenClosed(center.offset(-6, -2, -6), center.offset(6, 2, 6))) {
            if (this.level().getBlockState(pos).is(ModContent.NEST.get())
                    && this.level().getBlockEntity(pos) instanceof NestBlockEntity existing && existing.getEggCount() == 0) {
                nestPos = pos.immutable();
                nestMaterialScore = 0;
                return;
            }
        }
        // Score nearby available nest materials, consuming them as the hen gathers them.
        for (BlockPos pos : BlockPos.betweenClosed(center.offset(-6, -2, -6), center.offset(6, 2, 6))) {
            if (nestMaterialScore >= 10) break;
            BlockState state = this.level().getBlockState(pos);
            if (state.is(Blocks.GRASS) && this.level().getBlockState(pos.below()).is(Blocks.GRASS_BLOCK)) { this.level().destroyBlock(pos, false); nestMaterialScore += 1; }
            else if ((state.is(Blocks.TALL_GRASS) || state.is(Blocks.FERN) || state.is(Blocks.LARGE_FERN)) && this.level().getBlockState(pos.below()).is(Blocks.GRASS_BLOCK)) { this.level().destroyBlock(pos, false); nestMaterialScore += 2; }
            else if (state.is(Blocks.COBWEB)) { this.level().destroyBlock(pos, false); nestMaterialScore += 6; }
        }
        if (nestMaterialScore < 10) {
            for (ItemEntity item : this.level().getEntitiesOfClass(ItemEntity.class, this.getBoundingBox().inflate(6.0D))) {
                ItemStack stack = item.getItem();
                int count = stack.getCount();
                if (stack.is(Items.FEATHER)) { nestMaterialScore += Math.min(count, 2) * 6; stack.shrink(Math.min(count, 2)); }
                else if (stack.is(Items.STICK)) { nestMaterialScore += Math.min(count, 4) * 3; stack.shrink(Math.min(count, 4)); }
                else continue;
                if (stack.isEmpty()) item.discard(); else item.setItem(stack);
                if (nestMaterialScore >= 10) break;
            }
        }
        if (nestMaterialScore < 10) return;

        BlockPos nestSpot = findNestSpot(center);
        if (nestSpot == null) return;
        this.level().setBlock(nestSpot, ModContent.NEST.get().defaultBlockState(), 3);
        BlockEntity be = this.level().getBlockEntity(nestSpot);
        if (!(be instanceof NestBlockEntity)) return;
        nestPos = nestSpot.immutable();
        nestMaterialScore = 0;
        setSittingForNest(false);
    }

    private void layClutch(ServerLevel serverLevel, NestBlockEntity nest) {
        HeritageChicken rooster = serverLevel.getEntity(partnerUuid) instanceof HeritageChicken c ? c : null;
        if (rooster == null) return;
        int clutch = rollClutchSize(this.random);
        java.util.List<HeritageChicken> chicks = new java.util.ArrayList<>();
        for (int i = 0; i < clutch; i++) {
            HeritageChicken chick = (HeritageChicken) this.getBreedOffspring(serverLevel, rooster);
            chick.motherUuid = this.getUUID();
            chicks.add(chick);
        }
        nest.setClutch(chicks);
        prelayTicks = -1;
        setSittingForNest(true);
    }

    private BlockPos findNestSpot(BlockPos center) {
        for (BlockPos pos : BlockPos.betweenClosed(center.offset(-6, -2, -6), center.offset(6, 2, 6))) {
            BlockPos ground = pos.below();
            BlockState floor = this.level().getBlockState(ground);
            if (!(floor.is(Blocks.DIRT) || floor.is(Blocks.GRASS_BLOCK) || floor.is(Blocks.GRAVEL) || floor.is(Blocks.SAND))) continue;
            if (!this.level().getBlockState(pos).canBeReplaced()) continue;
            boolean blocked = false;
            for (BlockPos near : BlockPos.betweenClosed(pos.offset(-5, -1, -5), pos.offset(5, 1, 5))) {
                if (!this.level().getFluidState(near).isEmpty()) { blocked = true; break; }
            }
            if (blocked) continue;
            for (BlockPos near : BlockPos.betweenClosed(pos.offset(-3, -1, -3), pos.offset(3, 1, 3))) {
                if (this.level().getBlockState(near).is(Blocks.FARMLAND)) { blocked = true; break; }
            }
            if (!blocked) return pos.immutable();
        }
        return null;
    }

    private static int rollClutchSize(RandomSource random) {
        int roll = random.nextInt(10);
        if (roll == 0) return 1;
        if (roll <= 2) return 2;
        if (roll <= 6) return 3;
        if (roll <= 8) return 4;
        return 5;
    }

    @Override public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putByte("TfSex", this.entityData.get(SEX));
        tag.putByte("TfPrimary", this.entityData.get(PRIMARY));
        tag.putByte("TfSecondary", this.entityData.get(SECONDARY));
        tag.putBoolean("TfFreckled", this.entityData.get(FRECKLED));
        tag.putByte("TfFreckleColor", this.entityData.get(FRECKLE_COLOR));
        tag.putByte("TfHunger", this.entityData.get(HUNGER));
        tag.putBoolean("TfBlueEggGene", this.entityData.get(BLUE_EGG_GENE));
        tag.putBoolean("TfSittingForNest", this.entityData.get(SITTING_FOR_NEST));
        tag.putByte("TfEggColor", this.entityData.get(EGG_COLOR));
        tag.put("TfCarriedItem", this.entityData.get(CARRIED_ITEM).save(new CompoundTag()));
        tag.putBoolean("TfFeeding", this.entityData.get(FEEDING));
        tag.putInt("TfHungerTick", hungerTick);
        tag.putInt("TfRegenTick", regenTick);
        tag.putInt("TfStarvationTick", starvationTick);
        tag.putInt("TfForageCooldown", forageCooldown);
        tag.putInt("TfPrelayTicks", prelayTicks);
        tag.putInt("TfNestMaterialScore", nestMaterialScore);
        tag.putInt("TfNestRetryTicks", nestRetryTicks);
        if (partnerUuid != null) tag.putUUID("TfPartner", partnerUuid);
        if (motherUuid != null) tag.putUUID("TfMother", motherUuid);
        if (nestPos != null) tag.putLong("TfNestPos", nestPos.asLong());
    }

    @Override public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("TfSex")) this.entityData.set(SEX, tag.getByte("TfSex"));
        if (tag.contains("TfPrimary")) this.entityData.set(PRIMARY, tag.getByte("TfPrimary"));
        if (tag.contains("TfSecondary")) this.entityData.set(SECONDARY, tag.getByte("TfSecondary"));
        if (tag.contains("TfFreckled")) this.entityData.set(FRECKLED, tag.getBoolean("TfFreckled"));
        if (tag.contains("TfFreckleColor")) this.entityData.set(FRECKLE_COLOR, tag.getByte("TfFreckleColor"));
        if (tag.contains("TfHunger")) this.entityData.set(HUNGER, tag.getByte("TfHunger"));
        if (tag.contains("TfBlueEggGene")) this.entityData.set(BLUE_EGG_GENE, tag.getBoolean("TfBlueEggGene"));
        if (tag.contains("TfSittingForNest")) this.entityData.set(SITTING_FOR_NEST, tag.getBoolean("TfSittingForNest"));
        if (tag.contains("TfEggColor")) this.entityData.set(EGG_COLOR, tag.getByte("TfEggColor"));
        if (tag.contains("TfCarriedItem", CompoundTag.TAG_COMPOUND)) this.entityData.set(CARRIED_ITEM, ItemStack.of(tag.getCompound("TfCarriedItem")));
        if (tag.contains("TfFeeding")) this.entityData.set(FEEDING, tag.getBoolean("TfFeeding"));
        hungerTick = tag.getInt("TfHungerTick");
        regenTick = tag.getInt("TfRegenTick");
        starvationTick = tag.getInt("TfStarvationTick");
        forageCooldown = tag.getInt("TfForageCooldown");
        prelayTicks = tag.contains("TfPrelayTicks") ? tag.getInt("TfPrelayTicks") : -1;
        nestMaterialScore = tag.getInt("TfNestMaterialScore");
        nestRetryTicks = tag.getInt("TfNestRetryTicks");
        partnerUuid = tag.hasUUID("TfPartner") ? tag.getUUID("TfPartner") : null;
        motherUuid = tag.hasUUID("TfMother") ? tag.getUUID("TfMother") : null;
        nestPos = tag.contains("TfNestPos") ? BlockPos.of(tag.getLong("TfNestPos")) : null;
    }
}
