package com.gungle.taigaflock.block.entity;

import com.gungle.taigaflock.entity.EggGenetics;
import com.gungle.taigaflock.registry.ModContent;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;

/** Renders the clutch as small colored egg items sitting in the nest. */
public class NestRenderer implements BlockEntityRenderer<NestBlockEntity> {
    private final ItemRenderer itemRenderer;

    public NestRenderer(BlockEntityRendererProvider.Context context) {
        this.itemRenderer = context.getItemRenderer();
    }

    @Override
    public void render(NestBlockEntity nest, float partialTick, PoseStack poseStack, MultiBufferSource buffer,
                       int packedLight, int packedOverlay) {
        int count = Math.min(nest.getEggCount(), 5);
        for (int i = 0; i < count; i++) {
            ItemStack egg = new ItemStack(switch (nest.getEggColorAt(i)) {
                case WHITE -> ModContent.WHITE_EGG.get();
                case BROWN -> ModContent.BROWN_EGG.get();
                case BLUE -> ModContent.BLUE_EGG.get();
                case LIGHT_BROWN -> ModContent.LIGHT_BROWN_EGG.get();
                case OLIVE -> ModContent.OLIVE_EGG.get();
            });
            double[][] offsets = {{-0.16, -0.10}, {0.16, -0.10}, {0.0, 0.12}, {-0.19, 0.12}, {0.19, 0.12}};
            poseStack.pushPose();
            poseStack.translate(0.5 + offsets[i][0], 0.24, 0.5 + offsets[i][1]);
            poseStack.scale(0.38F, 0.38F, 0.38F);
            this.itemRenderer.renderStatic(egg, ItemDisplayContext.FIXED, packedLight, OverlayTexture.NO_OVERLAY,
                    poseStack, buffer, nest.getLevel(), i);
            poseStack.popPose();
        }
    }
}
