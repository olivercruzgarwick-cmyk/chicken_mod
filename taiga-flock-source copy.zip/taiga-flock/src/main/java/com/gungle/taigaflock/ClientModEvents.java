package com.gungle.taigaflock;

import com.gungle.taigaflock.entity.HeritageChickenRenderer;
import com.gungle.taigaflock.entity.HeritageChickenModel;
import com.gungle.taigaflock.block.entity.NestRenderer;
import com.gungle.taigaflock.registry.ModContent;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = TaigaFlock.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientModEvents {
    private ClientModEvents() {}
    @SubscribeEvent
    public static void registerLayers(EntityRenderersEvent.RegisterLayerDefinitions event) {
        event.registerLayerDefinition(HeritageChickenModel.LAYER_LOCATION, HeritageChickenModel::createBodyLayer);
    }

    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModContent.HERITAGE_CHICKEN.get(), HeritageChickenRenderer::new);
        event.registerBlockEntityRenderer(ModContent.NEST_BLOCK_ENTITY.get(), NestRenderer::new);
    }
}
