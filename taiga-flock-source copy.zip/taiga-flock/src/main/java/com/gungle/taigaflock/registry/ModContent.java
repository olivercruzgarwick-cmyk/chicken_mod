package com.gungle.taigaflock.registry;

import com.gungle.taigaflock.TaigaFlock;
import com.gungle.taigaflock.block.BlueberryBushBlock;
import com.gungle.taigaflock.block.NestBlock;
import com.gungle.taigaflock.block.entity.NestBlockEntity;
import com.gungle.taigaflock.entity.HeritageChicken;
import com.gungle.taigaflock.item.BlueberryLeavesItem;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModContent {
    private ModContent() {}

    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, TaigaFlock.MOD_ID);
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, TaigaFlock.MOD_ID);
    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, TaigaFlock.MOD_ID);
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITY_TYPES = DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, TaigaFlock.MOD_ID);
    public static final DeferredRegister<CreativeModeTab> CREATIVE_MODE_TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, TaigaFlock.MOD_ID);

    public static final RegistryObject<Block> BLUEBERRY_BUSH = BLOCKS.register("blueberry_bush",
            () -> new BlueberryBushBlock(BlockBehaviour.Properties.copy(net.minecraft.world.level.block.Blocks.SWEET_BERRY_BUSH)));
    public static final RegistryObject<Block> NEST = BLOCKS.register("nest",
            () -> new NestBlock(BlockBehaviour.Properties.of().strength(0.2F).sound(SoundType.GRASS).noOcclusion()));
    public static final RegistryObject<BlockEntityType<NestBlockEntity>> NEST_BLOCK_ENTITY = BLOCK_ENTITY_TYPES.register("nest",
            () -> BlockEntityType.Builder.of(NestBlockEntity::new, NEST.get()).build(null));

    public static final RegistryObject<Item> BLUEBERRIES = ITEMS.register("blueberries",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder().nutrition(1).saturationMod(0.1F).build())));
    public static final RegistryObject<Item> BLUEBERRY_LEAVES = ITEMS.register("blueberry_leaves",
            () -> new BlueberryLeavesItem(BlueberryLeavesItem.properties()));
    public static final RegistryObject<Item> BROWN_EGG = ITEMS.register("brown_egg", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> WHITE_EGG = ITEMS.register("white_egg", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> BLUE_EGG = ITEMS.register("blue_egg", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> LIGHT_BROWN_EGG = ITEMS.register("light_brown_egg", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> OLIVE_EGG = ITEMS.register("olive_egg", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> BLUEBERRY_BUSH_ITEM = ITEMS.register("blueberry_bush",
            () -> new BlockItem(BLUEBERRY_BUSH.get(), new Item.Properties()));
    public static final RegistryObject<Item> NEST_ITEM = ITEMS.register("nest",
            () -> new BlockItem(NEST.get(), new Item.Properties()));

    public static final RegistryObject<EntityType<HeritageChicken>> HERITAGE_CHICKEN = ENTITY_TYPES.register("heritage_chicken",
            () -> EntityType.Builder.of(HeritageChicken::new, MobCategory.CREATURE)
                    .sized(0.4F, 0.7F).clientTrackingRange(8).build("heritage_chicken"));
    public static final RegistryObject<Item> HERITAGE_CHICKEN_SPAWN_EGG = ITEMS.register("heritage_chicken_spawn_egg",
            () -> new SpawnEggItem(HERITAGE_CHICKEN.get(), 0xB68B5B, 0xE8D9B8, new Item.Properties()));

    public static final RegistryObject<CreativeModeTab> MAIN_TAB = CREATIVE_MODE_TABS.register("main", () -> CreativeModeTab.builder()
            .title(Component.translatable("itemGroup.taigaflock"))
            .icon(() -> new net.minecraft.world.item.ItemStack(BLUEBERRIES.get()))
            .displayItems((parameters, output) -> {
                output.accept(BLUEBERRY_BUSH_ITEM.get());
                output.accept(BLUEBERRIES.get());
                output.accept(BLUEBERRY_LEAVES.get());
                output.accept(NEST_ITEM.get());
                output.accept(WHITE_EGG.get());
                output.accept(BROWN_EGG.get());
                output.accept(BLUE_EGG.get());
                output.accept(LIGHT_BROWN_EGG.get());
                output.accept(OLIVE_EGG.get());
                output.accept(HERITAGE_CHICKEN_SPAWN_EGG.get());
            }).build());
}
