package com.gungle.taigaflock;

import com.gungle.taigaflock.registry.ModContent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.common.brewing.BrewingRecipeRegistry;
import com.gungle.taigaflock.brewing.BlueberryHealingBrewingRecipe;

@Mod(TaigaFlock.MOD_ID)
public class TaigaFlock {
    public static final String MOD_ID = "taigaflock";

    public TaigaFlock() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModContent.BLOCKS.register(bus);
        ModContent.ITEMS.register(bus);
        ModContent.ENTITY_TYPES.register(bus);
        ModContent.BLOCK_ENTITY_TYPES.register(bus);
        ModContent.CREATIVE_MODE_TABS.register(bus);
        bus.addListener(this::commonSetup);
    }

    private void commonSetup(final FMLCommonSetupEvent event) {
        event.enqueueWork(() -> BrewingRecipeRegistry.addRecipe(new BlueberryHealingBrewingRecipe()));
    }
}
