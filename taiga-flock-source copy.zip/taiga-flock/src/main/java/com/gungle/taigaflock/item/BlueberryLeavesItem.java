package com.gungle.taigaflock.item;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.level.Level;

/** Edible medicinal leaves; brewing them instead produces a Potion of Healing. */
public class BlueberryLeavesItem extends Item {
    public BlueberryLeavesItem(Properties properties) { super(properties); }

    @Override
    public ItemStack finishUsingItem(ItemStack stack, Level level, LivingEntity entity) {
        if (!level.isClientSide) entity.heal(2.0F);
        return super.finishUsingItem(stack, level, entity);
    }

    public static Properties properties() {
        return new Item.Properties().food(new FoodProperties.Builder()
                .nutrition(1).saturationMod(0.1F).alwaysEat().build());
    }
}
