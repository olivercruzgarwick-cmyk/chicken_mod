package com.gungle.taigaflock.entity;

import com.gungle.taigaflock.TaigaFlock;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ItemDisplayContext;

/** Renders the custom chicken rig and uses smaller proportions for chicks. */
public class HeritageChickenRenderer extends MobRenderer<HeritageChicken, HeritageChickenModel> {
    public HeritageChickenRenderer(EntityRendererProvider.Context context) {
        super(context, new HeritageChickenModel(context.bakeLayer(HeritageChickenModel.LAYER_LOCATION)), 0.25F);
        this.addLayer(new BeakItemLayer(this, context.getItemRenderer()));
    }

    @Override
    public ResourceLocation getTextureLocation(HeritageChicken chicken) {
        String color = chicken.getPrimaryColor().name().toLowerCase(java.util.Locale.ROOT);
        if (chicken.isBaby()) {
            boolean yellow = chicken.getPrimaryColor() == HeritageChicken.Plumage.WHITE
                    || chicken.getPrimaryColor() == HeritageChicken.Plumage.BUFF
                    || chicken.getPrimaryColor() == HeritageChicken.Plumage.RED;
            return new ResourceLocation(TaigaFlock.MOD_ID, "textures/entity/chick_" + (yellow ? "yellow" : "grey") + ".png");
        }
        if (chicken.hasFreckles()) {
            String spots = chicken.getFreckleColor().name().toLowerCase(java.util.Locale.ROOT);
            return new ResourceLocation(TaigaFlock.MOD_ID, "textures/entity/chicken_" + color + "_freckled_" + spots + ".png");
        }
        String sex = chicken.getSex() == HeritageChicken.Sex.ROOSTER ? "rooster" : "hen";
        return new ResourceLocation(TaigaFlock.MOD_ID, "textures/entity/chicken_" + color + "_" + sex + ".png");
    }

    @Override
    protected void scale(HeritageChicken chicken, PoseStack poseStack, float partialTickTime) {
        if (chicken.isBaby()) poseStack.scale(0.55F, 0.55F, 0.55F);
        else if (chicken.getSex() == HeritageChicken.Sex.ROOSTER) poseStack.scale(1.08F, 1.08F, 1.08F);
    }

    private static final class BeakItemLayer extends RenderLayer<HeritageChicken, HeritageChickenModel> {
        private final ItemRenderer itemRenderer;
        private BeakItemLayer(RenderLayerParent<HeritageChicken, HeritageChickenModel> parent, ItemRenderer itemRenderer) {
            super(parent);
            this.itemRenderer = itemRenderer;
        }
        @Override
        public void render(PoseStack poseStack, MultiBufferSource buffer, int packedLight, HeritageChicken chicken,
                           float limbSwing, float limbSwingAmount, float partialTick, float ageInTicks,
                           float netHeadYaw, float headPitch) {
            ItemStack carried = chicken.getCarriedItem();
            if (carried.isEmpty()) return;
            poseStack.pushPose();
            this.getParentModel().getHeadPart().translateAndRotate(poseStack);
            poseStack.translate(0.0D, -0.20D, -0.25D);
            poseStack.scale(0.28F, 0.28F, 0.28F);
            itemRenderer.renderStatic(chicken, carried, ItemDisplayContext.GROUND, false, poseStack, buffer,
                    chicken.level(), packedLight, OverlayTexture.NO_OVERLAY, chicken.getId());
            poseStack.popPose();
        }
    }
}
