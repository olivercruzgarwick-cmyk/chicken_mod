package com.gungle.taigaflock.block;

import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.BlockHitResult;
import com.gungle.taigaflock.registry.ModContent;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.SweetBerryBushBlock;
import net.minecraft.world.level.block.state.BlockState;

/** Sweet-berry-style growth with the vanilla prickling behavior intentionally removed. */
public class BlueberryBushBlock extends SweetBerryBushBlock {
    public BlueberryBushBlock(Properties properties) { super(properties); }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        if (state.getValue(AGE) >= 3) {
            if (!level.isClientSide) {
                popResource(level, pos, new ItemStack(ModContent.BLUEBERRIES.get(), 10));
                level.setBlock(pos, state.setValue(AGE, 1), 2);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
        return InteractionResult.PASS;
    }

    @Override
    public void entityInside(BlockState state, Level level, BlockPos pos, Entity entity) {
        // Blueberry bushes are harmless; unlike sweet berries, they never damage or slow entities.
    }
}
