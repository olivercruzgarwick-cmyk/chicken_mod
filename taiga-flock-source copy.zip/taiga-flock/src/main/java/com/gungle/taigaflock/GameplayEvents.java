package com.gungle.taigaflock;

import com.gungle.taigaflock.registry.ModContent;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.animal.Rabbit;
import net.minecraft.world.entity.animal.Chicken;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Small cross-entity interactions for the vanilla-plus blueberry item. */
@Mod.EventBusSubscriber(modid = TaigaFlock.MOD_ID)
public final class GameplayEvents {
    private GameplayEvents() {}

    @SubscribeEvent
    public static void replaceVanillaChicken(EntityJoinLevelEvent event) {
        if (!(event.getEntity() instanceof Chicken vanilla) || vanilla.getType() != EntityType.CHICKEN
                || !(event.getLevel() instanceof ServerLevel level)) return;
        var replacement = ModContent.HERITAGE_CHICKEN.get().create(level);
        if (replacement == null) return;
        replacement.moveTo(vanilla.getX(), vanilla.getY(), vanilla.getZ(), vanilla.getYRot(), vanilla.getXRot());
        replacement.setAge(vanilla.getAge());
        replacement.setCustomName(vanilla.getCustomName());
        replacement.setCustomNameVisible(vanilla.isCustomNameVisible());
        replacement.finalizeSpawn(level, level.getCurrentDifficultyAt(vanilla.blockPosition()), MobSpawnType.NATURAL, null, null);
        event.setCanceled(true);
        level.addFreshEntity(replacement);
    }

    @SubscribeEvent
    public static void lureRabbits(LivingEvent.LivingTickEvent event) {
        if (!(event.getEntity() instanceof Rabbit rabbit) || !(rabbit.level() instanceof ServerLevel level) || rabbit.isBaby()) return;
        var lurePlayer = level.getEntitiesOfClass(net.minecraft.world.entity.player.Player.class,
                rabbit.getBoundingBox().inflate(8.0D), player -> !player.isSpectator()
                        && (player.getMainHandItem().is(ModContent.BLUEBERRIES.get())
                        || player.getOffhandItem().is(ModContent.BLUEBERRIES.get())))
                .stream().min(java.util.Comparator.comparingDouble(rabbit::distanceToSqr)).orElse(null);
        if (lurePlayer != null && rabbit.distanceToSqr(lurePlayer) > 2.25D) {
            rabbit.getNavigation().moveTo(lurePlayer, 1.0D);
        }
    }

    @SubscribeEvent
    public static void onRabbitInteract(PlayerInteractEvent.EntityInteract event) {
        if (!(event.getTarget() instanceof Rabbit rabbit)) return;
        ItemStack held = event.getItemStack();
        if (!held.is(ModContent.BLUEBERRIES.get())) return;
        if (rabbit.isBaby() || rabbit.isInLove()) return;
        if (event.getLevel().isClientSide) {
            event.setCancellationResult(InteractionResult.SUCCESS);
            event.setCanceled(true);
            return;
        }
        rabbit.setInLove(event.getEntity());
        if (!event.getEntity().getAbilities().instabuild) held.shrink(1);
        event.setCancellationResult(InteractionResult.CONSUME);
        event.setCanceled(true);
    }
}
