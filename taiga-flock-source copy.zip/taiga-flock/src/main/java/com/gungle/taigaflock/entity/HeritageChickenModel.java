package com.gungle.taigaflock.entity;

import com.gungle.taigaflock.TaigaFlock;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/** A compact, custom cube-built chicken rig with sex-specific comb/tail silhouettes. */
public class HeritageChickenModel extends EntityModel<HeritageChicken> {
    public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(
            new ResourceLocation(TaigaFlock.MOD_ID, "heritage_chicken"), "main");

    private final ModelPart root;
    private final ModelPart body;
    private final ModelPart head;
    private final ModelPart leftWing;
    private final ModelPart rightWing;
    private final ModelPart leftLeg;
    private final ModelPart rightLeg;
    private final ModelPart comb;
    private final ModelPart tail;

    public HeritageChickenModel(ModelPart root) {
        this.root = root;
        this.body = root.getChild("body");
        this.head = root.getChild("head");
        this.leftWing = root.getChild("left_wing");
        this.rightWing = root.getChild("right_wing");
        this.leftLeg = root.getChild("left_leg");
        this.rightLeg = root.getChild("right_leg");
        this.comb = head.getChild("comb");
        this.tail = body.getChild("tail");
    }

    public ModelPart getHeadPart() { return head; }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer vertexConsumer, int packedLight,
                               int packedOverlay, float red, float green, float blue, float alpha) {
        root.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition body = root.addOrReplaceChild("body",
                CubeListBuilder.create().texOffs(0, 0).addBox(-3.0F, -4.0F, -3.0F, 6.0F, 8.0F, 6.0F),
                PartPose.offset(0.0F, 16.0F, 0.0F));
        body.addOrReplaceChild("tail",
                CubeListBuilder.create().texOffs(40, 0).addBox(-1.5F, -2.0F, 0.0F, 3.0F, 5.0F, 2.0F),
                PartPose.offset(0.0F, -1.5F, 3.0F));
        PartDefinition head = root.addOrReplaceChild("head",
                CubeListBuilder.create().texOffs(0, 16).addBox(-2.0F, -6.0F, -2.0F, 4.0F, 4.0F, 4.0F)
                        .texOffs(16, 16).addBox(-1.0F, -4.0F, -3.0F, 2.0F, 2.0F, 1.0F),
                PartPose.offset(0.0F, 12.0F, -1.0F));
        head.addOrReplaceChild("comb",
                CubeListBuilder.create().texOffs(24, 16).addBox(-1.0F, -8.5F, -1.0F, 2.0F, 2.0F, 2.0F),
                PartPose.ZERO);
        root.addOrReplaceChild("left_wing",
                CubeListBuilder.create().texOffs(32, 16).addBox(-1.0F, -2.0F, -2.0F, 2.0F, 4.0F, 4.0F),
                PartPose.offset(3.0F, 15.0F, 0.0F));
        root.addOrReplaceChild("right_wing",
                CubeListBuilder.create().texOffs(32, 16).mirror().addBox(-1.0F, -2.0F, -2.0F, 2.0F, 4.0F, 4.0F),
                PartPose.offset(-3.0F, 15.0F, 0.0F));
        root.addOrReplaceChild("left_leg",
                CubeListBuilder.create().texOffs(48, 16).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 4.0F, 2.0F),
                PartPose.offset(1.5F, 20.0F, 0.0F));
        root.addOrReplaceChild("right_leg",
                CubeListBuilder.create().texOffs(48, 16).mirror().addBox(-1.0F, 0.0F, -1.0F, 2.0F, 4.0F, 2.0F),
                PartPose.offset(-1.5F, 20.0F, 0.0F));
        return LayerDefinition.create(mesh, 64, 32);
    }

    @Override
    public void setupAnim(HeritageChicken chicken, float limbSwing, float limbSwingAmount,
                          float ageInTicks, float netHeadYaw, float headPitch) {
        head.yRot = netHeadYaw * ((float)Math.PI / 180F);
        head.xRot = headPitch * ((float)Math.PI / 180F);
        if (chicken.isFeedingPartner()) head.xRot += 0.35F;
        leftLeg.xRot = Mth.cos(limbSwing * 0.6662F) * 1.4F * limbSwingAmount;
        rightLeg.xRot = Mth.cos(limbSwing * 0.6662F + (float)Math.PI) * 1.4F * limbSwingAmount;
        leftWing.zRot = Mth.cos(ageInTicks * 0.3F) * 0.08F;
        rightWing.zRot = -leftWing.zRot;
        boolean rooster = !chicken.isBaby() && chicken.getSex() == HeritageChicken.Sex.ROOSTER;
        comb.visible = rooster;
        tail.visible = rooster;
        if (chicken.isSittingForNest()) {
            body.xRot = -0.18F;
            body.y = 18.0F;
            head.y = 14.0F;
            leftLeg.xRot = -0.7F;
            rightLeg.xRot = -0.7F;
        } else {
            body.xRot = 0.0F;
            body.y = 16.0F;
            head.y = 12.0F;
            if (chicken.isInWaterOrBubble()) {
                body.xRot = -0.22F;
                leftLeg.xRot = Mth.cos(ageInTicks * 0.45F) * 0.55F;
                rightLeg.xRot = Mth.cos(ageInTicks * 0.45F + (float)Math.PI) * 0.55F;
                leftWing.zRot = 0.18F;
                rightWing.zRot = -0.18F;
            } else if (chicken.getDeltaMovement().y > 0.12D) {
                body.xRot = -0.25F;
                leftLeg.xRot = -0.25F;
                rightLeg.xRot = -0.25F;
            }
        }
    }
}
