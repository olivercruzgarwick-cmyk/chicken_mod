#!/usr/bin/env python3
"""Offline sanity checks for Taiga Flock JSON resources and model texture refs."""
from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RESOURCES = ROOT / "src" / "main" / "resources"
ASSETS = RESOURCES / "assets" / "taigaflock"


def main() -> int:
    problems: list[str] = []
    json_files = sorted(RESOURCES.rglob("*.json"))
    for path in json_files:
        try:
            json.loads(path.read_text(encoding="utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            problems.append(f"Invalid JSON: {path.relative_to(ROOT)}: {exc}")

    texture_refs = 0
    model_refs = 0

    def resource_exists(value: str) -> bool:
        namespace, sep, relative = value.partition(":")
        if sep and namespace != "taigaflock":
            return True  # Vanilla/other-mod assets are supplied by their namespace.
        relative = relative if sep else value
        return (ASSETS / "models" / f"{relative}.json").is_file()

    def walk(value: object, origin: Path) -> None:
        nonlocal model_refs
        nonlocal texture_refs
        if isinstance(value, dict):
            for key, child in value.items():
                candidates: list[str] = []
                if key == "model" and isinstance(child, str):
                    model_refs += 1
                    if not resource_exists(child):
                        problems.append(
                            f"Missing model referenced by {origin.relative_to(ROOT)}: {child}"
                        )
                if key == "parent" and isinstance(child, str) and child.startswith("taigaflock:"):
                    model_refs += 1
                    parent = child.split(":", 1)[1]
                    parent_file = ASSETS / "models" / f"{parent}.json"
                    if not parent_file.is_file():
                        problems.append(
                            f"Missing parent model referenced by {origin.relative_to(ROOT)}: {child}"
                        )
                if key == "textures" and isinstance(child, dict):
                    candidates.extend(v for v in child.values() if isinstance(v, str))
                    # Walk the map too in case a format nests additional values.
                    walk(child, origin)
                elif key == "texture" and isinstance(child, str):
                    candidates.append(child)
                else:
                    walk(child, origin)

                for texture in candidates:
                    if texture.startswith("#"):
                        continue
                    namespace, sep, relative = texture.partition(":")
                    if sep and namespace != "taigaflock":
                        # Vanilla/other-namespace textures are supplied by their namespace.
                        continue
                    relative = relative if sep else texture
                    candidate = ASSETS / "textures" / relative
                    if candidate.suffix != ".png":
                        candidate = candidate.with_suffix(".png")
                    texture_refs += 1
                    if not candidate.is_file():
                        problems.append(
                            f"Missing texture referenced by {origin.relative_to(ROOT)}: {texture}"
                        )
        elif isinstance(value, list):
            for child in value:
                walk(child, origin)

    for path in ASSETS.rglob("*.json"):
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            continue  # Already reported above.
        walk(payload, path)

    # Textures selected dynamically by the custom chicken renderer.
    entity_textures = ASSETS / "textures" / "entity"
    colors = ("white", "grey", "black", "red", "buff")
    expected_entity_textures = {"chick_yellow.png", "chick_grey.png"}
    for color in colors:
        for sex in ("hen", "rooster"):
            expected_entity_textures.add(f"chicken_{color}_{sex}.png")
        for spot in colors:
            expected_entity_textures.add(f"chicken_{color}_freckled_{spot}.png")
    for name in sorted(expected_entity_textures):
        if not (entity_textures / name).is_file():
            problems.append(f"Missing dynamically-selected entity texture: {name}")

    expected_item_models = (
        "blue_egg", "blueberries", "blueberry_bush", "blueberry_leaves",
        "brown_egg", "heritage_chicken_spawn_egg", "light_brown_egg",
        "nest", "olive_egg", "white_egg",
    )
    item_models = ASSETS / "models" / "item"
    for name in expected_item_models:
        if not (item_models / f"{name}.json").is_file():
            problems.append(f"Missing item model for registered item: {name}")

    print(f"JSON files checked: {len(json_files)}")
    print(f"Model references checked: {model_refs}")
    print(f"Texture references checked: {texture_refs}")
    print(f"Dynamic entity textures checked: {len(expected_entity_textures)}")
    print(f"PNG textures present: {len(list(ASSETS.rglob('*.png')))}")
    if problems:
        print(f"Problems found: {len(problems)}", file=sys.stderr)
        for problem in problems:
            print(f" - {problem}", file=sys.stderr)
        return 1
    print("Resource sanity checks passed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
